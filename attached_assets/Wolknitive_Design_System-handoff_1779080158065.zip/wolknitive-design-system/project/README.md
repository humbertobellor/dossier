# Wolknitive Design System

> Reason built for reality.

Wolknitive.ai is a reasoning-AI company. The brand is scholarly, deliberate, warm-classical — a research imprint that happens to ship software. This system codifies that tone in pixels and prose.

This is a from-scratch identity. No prior codebase, Figma file, or brand book was provided — every token, font choice, and motif here is an original proposal designed against the brief (classic, serif, warm, teal + plum, custom W mark). Treat it as v0.1: opinionated but iterable.

---

## Source materials

| Source | Status |
| --- | --- |
| Codebase / repo | _none provided_ |
| Figma file | _none provided_ |
| Brand book or guidelines | _none provided_ |
| Existing site / screenshots | _none provided_ |

If any of these exist on your side, hand them over and the system will be retrofitted. Until then, every visual decision below is a proposal — flagged where assumptions were made.

---

## Index

```
README.md                  ← you are here
SKILL.md                   ← agent-skill manifest
colors_and_type.css        ← canonical CSS tokens (foundation + semantic + Bogart @font-face)

fonts/                     ← Bogart trial .ttf files (Thin → Black, regular + italic)

assets/
  logo-mark.svg            ← the WaI monogram (primary mark)
  logo-mark-monochrome.svg ← single-ink variant
  logo-wordmark.svg        ← horizontal wordmark with “olknitive.AI”
  pattern-rule.svg         ← editorial double-rule motif
  pattern-marginalia.svg   ← corner glyph ornament

preview/                   ← Design System cards (rendered in the Design System tab)

ui_kits/
  marketing/               ← wolknitive.ai — home, model card, docs (click-through)
  console/                 ← the reasoning workspace (trace + composer + ⌘K palette)
```

---

## Brand premise

Most AI brands lean futurist — gradients, neon, sans-serif, sci-fi. Wolknitive goes the opposite direction. The product is reasoning, and reasoning has a thousand-year visual heritage: the broadside, the encyclopedia, the law review, the engineering journal. We borrow from that lineage — serif type, ink-on-vellum color, marginalia, hairline rules, small caps — and apply it to a 2026 interface.

The result should feel **thought through**. Not rushed, not effusive. A serious tool for serious work, that still has warmth and personality.

The full **Content Fundamentals**, **Visual Foundations**, and **Iconography** sections live below. UI kits and preview cards link from this manifest.

---

## Content fundamentals

The voice is **a published essay, not a product tour.** Imagine a senior researcher writing in a quarterly journal: confident, plain, never breathless. Marketing pages and product strings share the same register — there is no separate "marketing voice."

### Tone
- **Considered, not clever.** No puns, no double meanings, no winks. A clean declarative sentence beats a clever one every time.
- **Plain, not corporate.** "We built this so models can show their work" — not "Wolknitive is an industry-leading platform that enables..."
- **Specific, not visionary.** Name the model, the benchmark, the dollar amount, the customer. Avoid "transform," "unlock," "empower," "harness."
- **Warm, not cold.** A serif page is not an austere page. The brand is allowed to like things, to admit uncertainty, to use the first person plural.

### Casing & punctuation
- **Sentence case everywhere.** Headings, buttons, nav items, labels — all sentence case. Never Title Case For Marketing Headlines.
- **Oxford commas, em-dashes.** We write like an editor copy-edits us. Em-dashes are spaced — like this — not tight—like—this.
- **Smart quotes.** Use “curly quotes” and apostrophes (’), never straight. Same for ellipses (…), not three dots.
- **Numerals from 10 up.** "Three reasons," "12 benchmarks." Always numerals for measurements, dollars, percentages, and tokens-per-second.
- **No exclamation points** in product UI. Sparingly (one per page max) in marketing.

### Pronouns
- **"We"** for the company. Not "Wolknitive offers..." but "We built..."
- **"You"** for the reader, only when giving direct instructions ("Paste a prompt below"). Avoid hypothetical "you" ("You might wonder..."); rewrite to first person or third person.

### Emoji & ornament
- **No emoji.** Anywhere. Not in marketing, not in docs, not in the product. The brand has its own glyphs (the diamond, the rule, the marginalia mark) for visual punctuation.
- **Footnotes, asterisks, and section marks** (§, ¶, †) are welcome — they fit the editorial vocabulary.

### Examples — yes

- > “Reason built for reality.”
- > “We trained a small model to admit when it doesn’t know. Here is what happened.”
- > “Paste a long document. Ask a hard question. See every step the model took to answer.”
- > “Wolknitive Reasoner v0.3 — Released April 14, 2026. Read the model card →”
- > “Three things changed since last quarter.”

### Examples — no

- ~~“Unleash the power of AI to transform your workflow! 🚀”~~ (breathless, vague, emoji)
- ~~“Our cutting-edge platform enables enterprises to leverage…”~~ (corporate, empty)
- ~~“Wolknitive's NEW Reasoning Engine Will Blow Your Mind”~~ (title case, hype, no specifics)
- ~~“Hey there 👋 ready to build?”~~ (chummy, emoji, second-person hypothetical)

### Microcopy reference

| Surface | Wolknitive | Not |
| --- | --- | --- |
| Submit button | `Run reasoning` | "Submit ✨" |
| Empty state | `No traces yet. Run a prompt to see the model think.` | "Nothing here! 😊" |
| Error | `The model timed out at 60s. Try a shorter prompt or raise the budget.` | "Oops! Something went wrong." |
| Confirm dialog | `Delete this trace? You can’t undo this.` | "Are you sure???" |
| Loading | `Reasoning…` (em-dash on first noun) | "Loading..." |

---

## Visual foundations

### The thesis
Editorial print, applied to software. Think the *New York Review of Books* opening spread, a Knopf hardcover title page, an Ed Tufte plate. The interface is a page; the content is the type; the chrome stays out of the way.

### Color
- **Warm vellum base** (`--vellum-50` #FAF6EC). Never pure white. The page is paper.
- **Ink** (`--ink` #14110B) — deep warm brown-black, not gray-black, not pure black.
- **Two primaries** in dialogue: **ink-teal** (`--teal-500` #1B4E4A) and **aubergine plum** (`--plum-500` #4E3457). Teal carries primary actions and product surfaces; plum is reserved for the second voice — quotes, secondary actions, hover states on cards, illustration accents.
- **Amber** (`--amber-500` #C7763B) is the highlight ink — for inline emphasis, badges, and one-of-a-kind callouts. Never a primary action color.
- **Moss + brick** for success and danger — muted, never saturated. No traffic-light green or fire-engine red.
- Use the full vellum scale for hairlines and tertiary surfaces. The system has no "gray-500" — it has `--vellum-500`, which has yellow-brown undertones.

### Type
- One serif does the heavy lifting: **Bogart** (Indian Type Foundry). Its full weight range (Thin → Black) and matching italics cover display, body, and editorial italic in a single family — so the page reads as one voice, not two. Trial files are bundled in `fonts/`; a production licence is required for ship.
- **Inter Tight** appears only for: small UI labels, eyebrow/category labels in caps, keyboard hints, table column headers. Never for body copy or headings.
- **JetBrains Mono** for code, prompts, model output, traces, IDs.
- **Italic carries real meaning.** Bogart's italics are warm and slightly cursive — used for emphasis, book titles, taglines, eyebrows. Don't italicize for decoration alone.
- **Drop caps** are allowed in long-form (docs, blog posts) — one per article, opening paragraph, in `--accent`.
- **Small caps** appear for category labels, footer headings, and section marks (§ I, § II).

### Backgrounds
- The product runs on `--vellum-50`. Sections may shift to `--bg-sunken` (`--vellum-100`) for contrast — never to white.
- **No gradients in UI chrome.** Period. (One exception: a subtle warm-vellum-to-vellum gradient under hero illustrations is allowed.)
- **Full-bleed photography** is rare; when used, it must be desaturated and warm-toned (sepia-leaning, never cool/blue).
- **Patterns:** hairline rules, marginalia glyphs, and occasional letterpress-style register marks. No noise textures, no grids, no dots.
- **Hand-drawn diagrams** are encouraged in marketing and docs — flat, single-ink line art on vellum, like a textbook plate.

### Animation
- **Reserved.** Most things don’t animate. The brand doesn't reward motion.
- **Easing:** custom `cubic-bezier(0.3, 0.1, 0.2, 1)` — slow start, quick settle. No bounces, no springs, no overshoots.
- **Durations:** 120ms for state changes, 240ms for surfaces appearing, 400ms for hero reveals. Anything longer feels self-important.
- **Fades** over slides. **Opacity + 4px transform** is the standard reveal — never 40px slides from offscreen.
- The reasoning trace UI is the only place with continuous motion (a typewriter cursor + token-by-token reveal); even there, plain.

### Hover & press
- **Hover (links):** underline thickens (1px → 1.5px) + color shifts one step warmer (`--teal-500` → `--teal-600`). Never opacity changes.
- **Hover (buttons):** background darkens one step (`--teal-500` → `--teal-600`). Cursor only — no scale, no shadow lift.
- **Hover (cards):** rule color strengthens (`--rule` → `--rule-strong`). No translation. No scale.
- **Press / active:** background darkens two steps. Inner shadow `--shadow-inset` for inset feel. No scale-down.
- **Focus:** 2px outline in `--accent` with 2px offset. Always visible — never just remove the outline.

### Borders & rules
- Borders are **hairlines** by default — 1px in `--rule` (warm vellum). Strong rules use `--rule-strong`.
- **The "editorial double-rule"** (1px solid + 0.5px hairline, 4px gap) is a brand motif — used to separate sections in long-form and at the foot of cards.
- Buttons and inputs default to a 1px border, not a fill — the brand prefers outlined controls except for primary CTAs.

### Shadows
- **Soft, low, warm-tinted.** Shadows use `rgba(20,17,11,…)`, never pure black. See `--shadow-1/2/3`.
- **No floating-card shadow ladders.** Cards rest on the page, separated by rules and tints — not by lift.
- Modals and popovers use `--shadow-3`. Toasts use `--shadow-2`. Buttons get no shadow by default.
- An optional `--shadow-inset` gives pressed buttons and recessed wells a letterpress feel.

### Radii
- **Restrained.** `--radius-sm` (4px) is the default for buttons, inputs, badges, cards. `--radius-md` (6px) for larger surfaces. Pills (`--radius-pill`) only for tags and avatars.
- **Never large rounded corners.** No 16px+ radius on UI cards. The brand is not a fintech app.

### Transparency & blur
- Used **only** for: modal scrims (24% ink, no blur), and the occasional fixed header on long pages (3px backdrop-blur on `--vellum-50`/92%).
- Never frosted-glass cards, never translucent buttons, never see-through nav.

### Imagery
- **Warm, sepia-leaning, slightly desaturated.** Photography gets a warm overlay (`--vellum-100` at 8% blend-mode: multiply) to sit on the page.
- **Black-and-white duotone** (ink + amber) is the gallery-quality treatment for editorial portraits.
- **Diagrams and illustrations** are flat line art on vellum, single ink with one accent (teal or plum). No 3D, no isometric, no stickers, no Memphis-style shapes.

### Layout
- **Generous margins.** A 12-column grid with extra outer gutter — the page should feel like a printed page. Body measure caps at 68ch.
- **Asymmetric spreads** are encouraged in marketing and docs (think: a wide outer column for marginalia, a narrower inner column for body).
- **Fixed elements** are kept minimal. The product nav lives in a static sidebar; marketing nav is a thin top bar that does not pin on scroll except on docs.
- **Content density** is "magazine," not "spreadsheet." Inputs are tall (40–44px). Tables breathe.

---

## Iconography

**Substitution flag:** No proprietary icon set was provided. The system uses **Lucide** via CDN (`https://unpkg.com/lucide@latest`) — its line-icon, low-stroke-contrast style harmonizes with the serif aesthetic better than filled or 3-tone systems would. Swap to your in-house set when ready.

### Rules
- **Line, not filled.** All icons are 1.5px stroke, round joins, round caps. Sized in 16/20/24 px steps.
- **Currentcolor only.** Icons take color from their text. No multi-color icons.
- **Used sparingly.** A wolknitive page can have zero icons. Add an icon only when it does work prose can't — navigation, status, action affordance. Never decorative.
- **No emoji.** Anywhere. (Restated for emphasis.) If you reach for an emoji, you want either a Lucide icon, a Wolknitive brand glyph (◇), or no glyph at all.
- **Unicode glyphs** are part of the system: `§ ¶ † ‡ — – … ◇ →`. Use them in body copy.

### Brand glyphs
Living in `assets/`:
- **◇ diamond** — the W mark's aperture, repurposed as a section divider and standalone glyph.
- **double-rule** — editorial section separator.
- **marginalia** — small corner ornament for cards and pull quotes.

### When to use what

| Need | Use |
| --- | --- |
| Navigation arrow | Unicode `→` or Lucide `arrow-right` |
| Section divider in prose | brand `◇` (centered, on its own line) |
| Status (success/error/warning) | Lucide `check-circle` / `x-circle` / `alert-triangle`, currentcolor |
| Tag / category | Text only — no icon |
| Bullet list | Hairline en-dash `–`, not a bullet |

---

## Caveats & substitutions (read me)

This system was built without source material from Wolknitive. The following are **proposals** that should be replaced or confirmed:

1. **Fonts.** Bogart is loaded from the **trial** files supplied (`fonts/Bogart-*-trial.ttf`). These are watermarked for evaluation only — obtain a production licence from Indian Type Foundry before shipping to customers. *Trial limitation:* the trial fonts replace digits 0–9 with circled-glyph watermarks. `colors_and_type.css` works around this by mapping every Bogart face’s `unicode-range` to exclude `U+0030–U+0039` and serving digits from Newsreader (CDN). Remove the two override `@font-face` blocks once the licensed Bogart is installed.
2. **Logo.** The WaI monogram (a leaning serif W + italic _a_ + capital I, baseline-ruled) is an original proposal. The proportions, overlap, and diamond aperture are starting points; have a typographer refine before production.
3. **Color values.** The teal/plum primaries and full vellum scale are tuned but unverified against any printed material or existing product. Hex values are starting points.
4. **Icon set.** Lucide via CDN. Replace with your set when available.
5. **Product surfaces.** No screenshots, codebase, or Figma was provided. The UI kits in `ui_kits/` are educated guesses at what Wolknitive's marketing site and reasoning console *should* look like — not recreations of anything real.

Anything in this system can change. Reach out and the system updates with you.
