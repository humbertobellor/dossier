---
name: wolknitive-design
description: Use this skill to generate well-branded interfaces and assets for Wolknitive (wolknitive.ai), either for production or for throwaway prototypes, mocks, and decks. Contains essential design guidelines, colors, type, fonts, brand assets, and UI kit components for prototyping. The brand is editorial-classical — serif type, warm vellum palette, ink-teal + aubergine plum primaries, "Reason built for reality."
user-invocable: true
---

Read the `README.md` file at the root of this skill first, then explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc.), copy assets out and create static HTML files for the user to view. Import `colors_and_type.css` at the top of any HTML you author so all CSS tokens and the Bogart font stack are available.

If working on production code, you can copy assets in and read the rules here to become an expert in designing with the Wolknitive brand. Note the trial-font caveat in the README — production work needs a licensed Bogart from Indian Type Foundry.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions (audience, surface, fidelity, length), and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick orientation

- **Brand premise:** editorial-classical applied to software. The interface is a page; the content is the type; the chrome stays out of the way.
- **Two primaries:** ink-teal `#1B4E4A` (actions, links, accent ink) and aubergine plum `#4E3457` (second voice, pull quotes, illustration).
- **Type:** Bogart (single family, weights 100–900) does display + body. Inter Tight only for small UI labels. JetBrains Mono for code.
- **Mark:** the "WaI" monogram (`assets/logo-mark.svg`) — a leaning serif W + italic lowercase _a_ + capital I, baseline ruled.
- **No emoji.** Anywhere. Use Lucide icons (line, 1.5px stroke, currentcolor) or brand glyphs (`◇ § ¶ † ‡`).
- **No gradients in UI chrome.** No rounded-corner card with colored left-border. No floating-card shadow ladders.

## Files

- `README.md` — the long version, with Content Fundamentals, Visual Foundations, Iconography, and caveats.
- `colors_and_type.css` — all tokens. Import this once at the root of any HTML.
- `fonts/` — Bogart trial files (Thin → Black, regular + italic).
- `assets/` — logo mark, monochrome mark, wordmark, brand glyphs.
- `preview/` — Design System cards (one HTML file per concept).
- `ui_kits/marketing/` — full marketing site recreation (home, model card, docs).
- `ui_kits/console/` — reasoning workspace app (trace detail + new trace + command palette).
