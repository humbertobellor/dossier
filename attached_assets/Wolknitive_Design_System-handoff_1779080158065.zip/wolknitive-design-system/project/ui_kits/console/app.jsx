/* Console — app shell + fake state */

const { useState, useEffect } = React;

const TRACES = [
  {
    id: "01HXY3K9F4",
    title: "Reconcile three customer-count figures across the 2025 annual report.",
    age: "3m",
    bucket: "today",
    overall: "0.71",
    steps: [
      { calib: 0.92, text: "<b>Locate the three figures.</b> Found on p.4 (\"1.2 million paying customers\"), p.9 (\"approximately 1.4 m active\"), and p.22 (\"1.18 m subscribed accounts\"). All footnoted to the same source: <code>internal/customer-ops/q4.csv</code>." },
      { calib: 0.84, text: "<b>Disambiguate the denominators.</b> Page 4 is fiscal-year-end (Jan 31). Page 9 is calendar-Q4 monthly active. Page 22 is \"subscribed\" — a billing concept, not a usage concept. Three different definitions of customer." },
      { calib: 0.61, text: "<b>Translate to a common metric.</b> Convert all three to fiscal-year-end paying customers. Page 9 net-of-trials gives 1.21 m. Page 22 includes one annual contract renewed in Feb — backing it out yields 1.17 m. Page 4 is canonical at 1.20 m." },
      { calib: 0.42, text: "<b>Verify against source CSV.</b> <em>The CSV was not attached to this trace.</em> I’m using the report’s footnoted totals. If the underlying CSV shows different rounding (e.g. half-up to nearest 10k vs. 100k), the 1.17 m and 1.20 m figures could swap order." },
      { calib: 0.87, text: "<b>Conclude.</b> Within ±3 %, all three figures describe the same customer base under three different operational definitions. The report is internally consistent; the apparent contradiction is presentation, not arithmetic." },
    ],
    answer: "All three numbers are correct — they describe the same customer base under three different definitions (fiscal-year-end, calendar-Q4 active, and billing-subscribed). The arithmetic is consistent within ±3 %; the contradiction is editorial.",
  },
  {
    id: "01HXY1P2M9",
    title: "What did the author omit from section three?",
    age: "12m",
    bucket: "today",
    overall: "0.66",
    steps: [
      { calib: 0.78, text: "<b>Index section three.</b> Eight sub-sections, 14 pages, two figures. No appendix." },
      { calib: 0.58, text: "<b>Cross-reference earlier sections.</b> Section one promises three case studies; section three delivers two. The third (\"Henderson Mfg.\") is named but never described." },
    ],
    answer: "Section three omits the Henderson Mfg. case study promised in section one. No other gaps detected at the section level.",
  },
  { id: "01HXW0Z4VV", title: "Summarize the lab’s March eval results vs. Feb baseline.", age: "yest", bucket: "today", overall: "—", steps: [], answer: "" },
  { id: "01HXV7AAQQ", title: "Plain-English explanation of calibration RL for a CFO.", age: "1d", bucket: "week", overall: "—", steps: [], answer: "" },
  { id: "01HXU2HHRR", title: "Compare licence terms: WSL-1.0 vs Apache-2.0.", age: "2d", bucket: "week", overall: "—", steps: [], answer: "" },
  { id: "01HXR1FFSS", title: "Find the contradiction in §4 of the policy memo.", age: "4d", bucket: "week", overall: "—", steps: [], answer: "" },
];

function App() {
  const [currentId, setCurrentId] = useState(TRACES[0].id);
  const [composerVal, setComposerVal] = useState("");
  const [doc, setDoc] = useState("annual-report-2025.pdf");
  const [cmdOpen, setCmdOpen] = useState(false);
  const [view, setView] = useState("trace"); // "trace" | "empty"

  const current = TRACES.find(t => t.id === currentId);

  useEffect(() => {
    const h = e => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setCmdOpen(o => !o); }
      if (e.key === "Escape") setCmdOpen(false);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, []);

  const openTrace = id => { setCurrentId(id); setView("trace"); };
  const newTrace = () => { setView("empty"); setComposerVal(""); };
  const onExample = q => { setComposerVal(q); setView("empty"); };
  const send = () => {
    if (!composerVal.trim()) return;
    // Pretend: snap to the first trace
    setCurrentId(TRACES[0].id); setView("trace"); setComposerVal("");
  };

  return (
    <div className="cn-workspace" data-screen-label={view === "empty" ? "02 New trace" : "01 Trace detail"}>
      <Sidebar traces={TRACES} current={currentId} onOpen={openTrace} onNew={newTrace}/>
      <div className="cn-main">
        <TopBar trace={view === "trace" ? current : null} onCmd={() => setCmdOpen(true)}/>
        {view === "trace"
          ? <TraceView trace={current}/>
          : <EmptyState onExample={onExample}/>}
        <Composer
          value={composerVal}
          onChange={setComposerVal}
          onSend={send}
          doc={doc}
          onAttach={() => setDoc(doc ? null : "annual-report-2025.pdf")}
        />
      </div>
      <CommandPalette open={cmdOpen} onClose={() => setCmdOpen(false)} onAction={() => {}}/>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
