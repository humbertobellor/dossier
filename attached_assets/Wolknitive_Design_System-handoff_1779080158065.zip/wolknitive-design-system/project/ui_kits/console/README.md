# Console UI kit

The Wolknitive reasoning workspace — a single-window app, two screens, click-through.

```
index.html        ← entry; loads CSS + JSX
console.css       ← layout + components (relies on ../../colors_and_type.css)
components.jsx    ← Sidebar, TopBar, TraceView, Composer, EmptyState, CommandPalette, WMark, Ic
app.jsx           ← app shell + fake state
```

## Screens

1. **Trace detail** — sidebar with prompt history, top bar with breadcrumb + model selector, scrollable trace of numbered Roman-numeral steps with calibration bars, final Answer card with overall calibration.
2. **New trace / Empty state** — large brand mark, italic Bogart prompt, three example prompts as starters.
3. **Command palette** (⌘ K) — overlay with input + grouped commands.

## Patterns to copy

- `.cn-step` grid: `72px 1fr 110px` — Roman numeral, body prose, calibration meter.
- The low-calibration step is highlighted with a soft amber gradient — not a banner.
- Sidebar items prefix with `◇` only when active.
- Final answer card has a 3px teal top rule (the brand’s only use of an accent border).
- ⌘K opens an editorial command palette — items are grouped by category (`Action`, `Model`, `Help`).

## What is not here

- Real model calls — `app.jsx` ships seeded fake traces.
- File browser, settings, billing — single-screen demo only.
