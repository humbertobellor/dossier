/* Wolknitive console UI kit — components + app */

const { useState, useEffect, useMemo } = React;

function Ic({ d, fill="none" }) {
  return (
    <svg viewBox="0 0 24 24" fill={fill} stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d={d}/>
    </svg>
  );
}

// Simple W mark (kept for sidebar; the "WaI" full monogram lives at assets/logo-mark.svg)
function WMark({ size = 26 }) {
  return (
    <svg width={size} height={size * (170/240)} viewBox="0 0 240 170" aria-label="Wolknitive">
      <g fill="none" stroke="currentColor" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round">
        <path d="M120 38 C95 30, 70 32, 56 46 C46 56, 42 70, 46 82 C36 86, 30 96, 32 110 C34 124, 44 134, 58 136 C62 148, 78 154, 96 152 C106 156, 118 158, 120 158 Z"/>
        <path d="M120 38 C145 30, 170 32, 184 46 C194 56, 198 70, 194 82 C204 86, 210 96, 208 110 C206 124, 196 134, 182 136 C178 148, 162 154, 144 152 C134 156, 122 158, 120 158 Z"/>
      </g>
      <g fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
        <path d="M120 38 L 120 156"/>
        <path d="M62 70 L 86 70 L 86 86"/><path d="M48 96 L 72 96"/><path d="M62 118 L 84 118 L 84 138"/>
        <path d="M178 70 L 154 70 L 154 86"/><path d="M192 96 L 168 96"/><path d="M178 118 L 156 118 L 156 138"/>
        <rect x="0" y="78" width="20" height="8" rx="1" fill="currentColor"/>
        <path d="M20 82 L 42 82"/>
        <rect x="0" y="100" width="20" height="8" rx="1" fill="currentColor"/>
        <path d="M20 104 L 42 104"/>
        <rect x="220" y="78" width="20" height="8" rx="1" fill="currentColor"/>
        <path d="M220 82 L 198 82"/>
        <rect x="220" y="100" width="20" height="8" rx="1" fill="currentColor"/>
        <path d="M220 104 L 198 104"/>
        <path d="M96 38 L 96 18"/>
        <path d="M120 36 L 120 6"/>
        <path d="M144 38 L 144 18"/>
      </g>
      <g fill="currentColor">
        <circle cx="86" cy="86" r="3.2"/><circle cx="72" cy="96" r="3.2"/><circle cx="84" cy="138" r="3.2"/>
        <circle cx="154" cy="86" r="3.2"/><circle cx="168" cy="96" r="3.2"/><circle cx="156" cy="138" r="3.2"/>
        <circle cx="96" cy="14" r="4"/><circle cx="120" cy="2" r="4"/><circle cx="144" cy="14" r="4"/>
      </g>
    </svg>
  );
}

// ---------- Sidebar ----------
function Sidebar({ traces, current, onOpen, onNew, onCmd }) {
  return (
    <aside className="cn-side">
      <div className="cn-side__head">
        <WMark size={22}/>
        <div className="cn-side__brandtext">
          <span className="name">Wolknitive</span>
          <span className="dot">.ai</span>
        </div>
      </div>
      <button className="cn-side__newprompt" onClick={onNew}>
        New trace <span className="k">⌘ N</span>
      </button>
      <div className="cn-side__section">
        <h4>Today</h4>
        <div className="cn-side__list">
          {traces.filter(t => t.bucket === "today").map(t => (
            <div key={t.id} className={"cn-side__item" + (t.id === current ? " active" : "")} onClick={() => onOpen(t.id)}>
              <span className="glyph">◇</span>
              <span className="name">{t.title}</span>
              <span className="age">{t.age}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="cn-side__section">
        <h4>Earlier this week</h4>
        <div className="cn-side__list">
          {traces.filter(t => t.bucket === "week").map(t => (
            <div key={t.id} className={"cn-side__item" + (t.id === current ? " active" : "")} onClick={() => onOpen(t.id)}>
              <span className="glyph">◇</span>
              <span className="name">{t.title}</span>
              <span className="age">{t.age}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="cn-side__footer">
        <div className="av">EM</div>
        <div className="who">Eve Mercier<small>research · pro</small></div>
      </div>
    </aside>
  );
}

// ---------- Top bar ----------
function TopBar({ trace, onCmd }) {
  return (
    <div className="cn-bar">
      <div className="cn-bar__crumb">
        <span>Workspace</span>
        <span>/</span>
        <b>{trace?.title || "New trace"}</b>
      </div>
      <button className="cn-bar__model">
        <span className="dot"/>
        <span>Reasoner v0.3 · 7B</span>
        <span style={{color: "var(--vellum-400)"}}>↓</span>
      </button>
      <button className="cn-bar__icon" onClick={onCmd} title="Command palette (⌘K)">
        <Ic d="M11 4a7 7 0 11-7 7M21 21l-4.5-4.5"/>
      </button>
      <button className="cn-bar__icon" title="Share">
        <Ic d="M4 12v7a1 1 0 001 1h14a1 1 0 001-1v-7M16 6l-4-4-4 4M12 2v14"/>
      </button>
      <button className="cn-bar__icon" title="Settings">
        <Ic d="M12 15a3 3 0 100-6 3 3 0 000 6zM19.4 15a1.7 1.7 0 00.34 1.87l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.7 1.7 0 00-1.87-.34 1.7 1.7 0 00-1 1.55V21a2 2 0 01-4 0v-.09a1.7 1.7 0 00-1.11-1.55 1.7 1.7 0 00-1.87.34l-.06.06a2 2 0 11-2.83-2.83l.06-.06a1.7 1.7 0 00.34-1.87 1.7 1.7 0 00-1.55-1H3a2 2 0 010-4h.09a1.7 1.7 0 001.55-1.11 1.7 1.7 0 00-.34-1.87l-.06-.06a2 2 0 112.83-2.83l.06.06a1.7 1.7 0 001.87.34H9a1.7 1.7 0 001-1.55V3a2 2 0 014 0v.09a1.7 1.7 0 001 1.55 1.7 1.7 0 001.87-.34l.06-.06a2 2 0 112.83 2.83l-.06.06a1.7 1.7 0 00-.34 1.87V9a1.7 1.7 0 001.55 1H21a2 2 0 010 4h-.09a1.7 1.7 0 00-1.55 1z"/>
      </button>
    </div>
  );
}

// ---------- Trace view (full reasoning trace) ----------
function TraceView({ trace }) {
  if (!trace) return null;
  return (
    <div className="cn-trace">
      <div className="cn-trace__head">
        <div className="eyebrow">◇ Trace · {trace.id}</div>
        <h1>{trace.title}</h1>
        <div className="meta">
          <span><b>Model</b> Reasoner v0.3</span>
          <span><b>Budget</b> 32k tokens</span>
          <span><b>Duration</b> 14.2s</span>
          <span><b>Steps</b> {trace.steps.length}</span>
          <span><b>Calibration</b> {trace.overall}</span>
        </div>
      </div>

      {trace.steps.map((s, i) => (
        <div key={i} className={"cn-step" + (s.calib < 0.5 ? " low" : "") + (s.error ? " error" : "")}>
          <div className="num">{romanize(i + 1)}.</div>
          <div className="body" dangerouslySetInnerHTML={{__html: s.text}}/>
          <div className="calib">
            <span className="lbl">Calibration</span>
            <span className="score">{s.calib.toFixed(2)}</span>
            <div className="bar"><div style={{width: `${Math.round(s.calib * 100)}%`}}/></div>
          </div>
        </div>
      ))}

      <div className="cn-final">
        <h3>Answer</h3>
        <p>{trace.answer}</p>
        <div className="conf">
          Overall calibration <b>{trace.overall}</b> — confidence depressed by <em>step iv (0.42)</em>, where the model could not verify the source figure against the document.
        </div>
      </div>
    </div>
  );
}

function romanize(n) {
  const arr = ["i","ii","iii","iv","v","vi","vii","viii","ix","x","xi","xii"];
  return arr[n - 1] || n;
}

// ---------- Composer ----------
function Composer({ value, onChange, onSend, doc, onAttach }) {
  return (
    <div className="cn-composer">
      <div className="cn-composer__row">
        <textarea
          value={value}
          onChange={e => onChange(e.target.value)}
          onKeyDown={e => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) onSend(); }}
          placeholder="Ask the reasoner a question. Attach a document for grounded answers."
          rows={2}
        />
        <div className="actions">
          <button className="send" onClick={onSend}>
            Run reasoning <span className="k">⌘ ↵</span>
          </button>
        </div>
      </div>
      <div className="chips">
        <span style={{color: "var(--vellum-500)"}}>Context —</span>
        <span className={"chip" + (doc ? " attached" : "")} onClick={onAttach}>
          <svg viewBox="0 0 24 24"><path d="M21 12.8V19a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h6.2M16 3h5v5M21 3l-9 9"/></svg>
          {doc ? doc : "Attach document"}
        </span>
        <span className="chip">
          <svg viewBox="0 0 24 24"><path d="M12 2v20M2 12h20"/></svg>
          System prompt
        </span>
        <span className="chip">
          <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>
          Budget · 32k
        </span>
      </div>
    </div>
  );
}

// ---------- Empty state ----------
function EmptyState({ onExample }) {
  const ex = [
    "Why does the report refer to fiscal year, not calendar year?",
    "Reconcile the three customer-count figures on pages 4, 9, and 22.",
    "What did the author leave out of section three? Cite passages.",
  ];
  return (
    <div className="cn-empty">
      <div>
        <div className="mark"><WMark size={56}/></div>
        <h2>What should we <em>reason about?</em></h2>
        <p>A small reasoning model that traces its thinking step by step — and admits, in plain language, when it doesn’t know.</p>
        <div className="examples">
          {ex.map((q, i) => (
            <button className="example" key={i} onClick={() => onExample(q)}>
              <span>{q}</span><span className="arr">→</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ---------- Command palette ----------
function CommandPalette({ open, onClose, onAction }) {
  const [q, setQ] = useState("");
  const items = [
    { id: "new", label: "New trace", group: "Action", k: "⌘ N" },
    { id: "model", label: "Switch model · Reasoner v0.3 → v0.2", group: "Model" },
    { id: "budget", label: "Set reasoning budget…", group: "Setting" },
    { id: "share", label: "Share this trace as a link", group: "Action", k: "⌘ ⇧ S" },
    { id: "export", label: "Export trace as Markdown", group: "Action" },
    { id: "docs", label: "Open docs — calibration", group: "Help" },
    { id: "feedback", label: "Send feedback to the lab", group: "Help" },
  ];
  const filtered = items.filter(it => it.label.toLowerCase().includes(q.toLowerCase()));
  if (!open) return null;
  return (
    <div className="cn-cmd-scrim" onClick={onClose}>
      <div className="cn-cmd" onClick={e => e.stopPropagation()}>
        <input autoFocus value={q} onChange={e => setQ(e.target.value)} placeholder="Type a command, search settings…"/>
        <ul>
          {filtered.map((it, i) => (
            <li key={it.id} className={i === 0 ? "active" : ""} onClick={() => { onAction(it.id); onClose(); }}>
              <span className="sym">{it.group}</span>
              <span style={{flex: 1}}>{it.label}</span>
              {it.k && <span style={{fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--vellum-500)"}}>{it.k}</span>}
            </li>
          ))}
        </ul>
        <div className="ftr">
          <span><kbd>↵</kbd> open</span>
          <span><kbd>↑</kbd> <kbd>↓</kbd> navigate</span>
          <span><kbd>esc</kbd> close</span>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Ic, WMark, Sidebar, TopBar, TraceView, Composer, EmptyState, CommandPalette });
