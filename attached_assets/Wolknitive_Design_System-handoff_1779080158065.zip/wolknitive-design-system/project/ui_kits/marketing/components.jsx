/* Wolknitive marketing UI kit — shared components. */

const { useState } = React;

// ---------- Brand mark (inline SVG so it picks up currentColor) ----------
function WMark({ size = 32 }) {
  return (
    <svg width={size} height={size * (170/240)} viewBox="0 0 240 170" aria-label="Wolknitive">
      <g fill="none" stroke="currentColor" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round">
        <path d="M120 38 C95 30, 70 32, 56 46 C46 56, 42 70, 46 82 C36 86, 30 96, 32 110 C34 124, 44 134, 58 136 C62 148, 78 154, 96 152 C106 156, 118 158, 120 158 Z"/>
        <path d="M120 38 C145 30, 170 32, 184 46 C194 56, 198 70, 194 82 C204 86, 210 96, 208 110 C206 124, 196 134, 182 136 C178 148, 162 154, 144 152 C134 156, 122 158, 120 158 Z"/>
      </g>
      <g fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
        <path d="M120 38 L 120 156"/>
        <path d="M62 70 L 86 70 L 86 86"/><path d="M48 96 L 72 96"/><path d="M62 118 L 84 118 L 84 138"/>
        <path d="M178 70 L 154 70 L 154 86"/><path d="M192 96 L 168 96"/><path d="M178 118 L 156 118 L 156 138"/>
        <rect x="0" y="78" width="20" height="8" rx="1" fill="currentColor"/>
        <path d="M20 82 L 42 82"/>
        <rect x="0" y="100" width="20" height="8" rx="1" fill="currentColor"/>
        <path d="M20 104 L 42 104"/>
        <rect x="220" y="78" width="20" height="8" rx="1" fill="currentColor"/>
        <path d="M220 82 L 198 82"/>
        <rect x="220" y="100" width="20" height="8" rx="1" fill="currentColor"/>
        <path d="M220 104 L 198 104"/>
        <path d="M96 38 L 96 18"/>
        <path d="M120 36 L 120 6"/>
        <path d="M144 38 L 144 18"/>
      </g>
      <g fill="currentColor">
        <circle cx="86" cy="86" r="3.2"/><circle cx="72" cy="96" r="3.2"/><circle cx="84" cy="138" r="3.2"/>
        <circle cx="154" cy="86" r="3.2"/><circle cx="168" cy="96" r="3.2"/><circle cx="156" cy="138" r="3.2"/>
        <circle cx="96" cy="14" r="4"/><circle cx="120" cy="2" r="4"/><circle cx="144" cy="14" r="4"/>
      </g>
    </svg>
  );
}

function Brand({ onClick }) {
  return (
    <a className="wk-brand" onClick={onClick}>
      <WMark size={24}/>
      <div className="wk-brand__text">
        <span className="name">Wolknitive</span><span className="dot">.ai</span>
      </div>
    </a>
  );
}

// ---------- Top nav ----------
function TopNav({ current, onNavigate }) {
  const items = [
    { id: "product", label: "Product" },
    { id: "models", label: "Models" },
    { id: "research", label: "Research" },
    { id: "docs", label: "Docs" },
    { id: "pricing", label: "Pricing" },
  ];
  return (
    <nav className="wk-nav">
      <div className="wk-container wk-nav__inner">
        <Brand onClick={() => onNavigate("home")}/>
        <div className="wk-nav__links">
          {items.map(it => (
            <a
              key={it.id}
              className={"wk-nav__link" + (current === it.id ? " active" : "")}
              onClick={() => onNavigate(it.id)}
            >{it.label}</a>
          ))}
        </div>
        <div className="wk-nav__right">
          <a className="wk-btn wk-btn--ghost" onClick={() => onNavigate("docs")}>Sign in</a>
          <a className="wk-btn wk-btn--primary" onClick={() => onNavigate("console")}>
            Open console <span className="kbd">⌘&thinsp;K</span>
          </a>
        </div>
      </div>
    </nav>
  );
}

// ---------- Footer ----------
function Footer({ onNavigate }) {
  return (
    <footer className="wk-footer">
      <div className="wk-container">
        <div className="wk-footer__grid">
          <div className="wk-footer__brand">
            <WMark size={32}/>
            <p className="blurb">Reason built for reality. Wolknitive is a small lab in New York making models that show their work.</p>
          </div>
          <div>
            <h4>Product</h4>
            <ul>
              <li><a onClick={() => onNavigate("models")}>Reasoner v0.3</a></li>
              <li><a>Console</a></li>
              <li><a>API</a></li>
              <li><a>Pricing</a></li>
            </ul>
          </div>
          <div>
            <h4>Research</h4>
            <ul>
              <li><a>Papers</a></li>
              <li><a>Evals</a></li>
              <li><a onClick={() => onNavigate("article")}>Model card</a></li>
              <li><a>Changelog</a></li>
            </ul>
          </div>
          <div>
            <h4>Company</h4>
            <ul>
              <li><a>About</a></li>
              <li><a>Careers — 4 open</a></li>
              <li><a>Press</a></li>
              <li><a>Contact</a></li>
            </ul>
          </div>
          <div>
            <h4>Legal</h4>
            <ul>
              <li><a>Privacy</a></li>
              <li><a>Terms</a></li>
              <li><a>Acceptable use</a></li>
              <li><a>Security</a></li>
            </ul>
          </div>
        </div>
        <div className="wk-footer__legal">
          <span>© 2026 Wolknitive Inc. — Made in NYC.</span>
          <span>v0.3.1 ◇ release April&nbsp;14, 2026</span>
        </div>
      </div>
    </footer>
  );
}

// ---------- Hero ----------
function Hero({ onCta }) {
  return (
    <section className="wk-hero">
      <div className="wk-container">
        <div className="wk-hero__eyebrow">
          <span className="diamond">◇</span>
          <span>Reasoner v0.3 — released April&nbsp;14, 2026</span>
        </div>
        <h1>Reason built<br/>for <em>reality.</em></h1>
        <p className="wk-hero__lede">
          A small reasoning model that traces its thinking step by step — and admits, in plain language, when it doesn’t know.
        </p>
        <div className="wk-hero__cta">
          <a className="wk-btn wk-btn--primary wk-btn--lg" onClick={onCta}>
            Open the console <span className="kbd">⌘&thinsp;↵</span>
          </a>
          <a className="wk-btn wk-btn--secondary wk-btn--lg" onClick={onCta}>
            Read the model card →
          </a>
        </div>
        <div className="wk-hero__rule"/>
      </div>
    </section>
  );
}

// ---------- Manifesto ----------
function Manifesto() {
  return (
    <section className="wk-manifesto wk-container">
      <h2>A reasoning model<br/>is not a <em>magic trick.</em></h2>
      <div className="wk-manifesto__body">
        <p>We trained a small model to admit when it doesn’t know. It still hallucinates, occasionally. But it now tells you which step of the trace it’s least confident in — and that, it turns out, is most of the value.</p>
        <p>Most reasoning demos show the right answer to the easy question, fast. Reality is the long PDF, the contradicting numbers, the question that should not have been asked. We built for that.</p>
        <p className="wk-manifesto__sign">— The Wolknitive lab</p>
      </div>
    </section>
  );
}

// ---------- Features ----------
function Features() {
  const items = [
    { n: "i.", title: "Traces, not vibes", body: "Every output ships with a tree of intermediate steps you can inspect, fork, and re-run with a different model." },
    { n: "ii.", title: "Calibrated uncertainty", body: "When the model is unsure, it says so — at the granularity of the specific step, not the answer." },
    { n: "iii.", title: "Quiet by default", body: "The trace UI is reserved. No loading sparkles, no thinking emoji. Just text setting itself on a warm page." },
    { n: "iv.", title: "Long-context grounded", body: "Tuned for 200k-token documents. Citations are inline and verifiable against the source passage." },
    { n: "v.", title: "Honest benchmarks", body: "We publish raw outputs, prompts, and seeds for every eval. No best-of-N, no judge models." },
    { n: "vi.", title: "Local first", body: "The Reasoner v0.3 weights are 7B. Run on a laptop. The console works offline." },
  ];
  return (
    <section className="wk-features">
      <div className="wk-container">
        <div className="wk-features__head">
          <h2>Six small commitments. <em>Each one specific.</em></h2>
          <div className="meta">§ I — Product</div>
        </div>
        <div className="wk-feat-grid">
          {items.map(it => (
            <div className="wk-feat" key={it.n}>
              <div className="num">{it.n}</div>
              <h3>{it.title}</h3>
              <p>{it.body}</p>
              <div className="more">Read more →</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ---------- Benchmark band ----------
function BenchmarkBand() {
  const rows = [
    { name: "Reasoner v0.3", size: "7B",  gpqa: "72.4", math: "84.1", calib: "0.91", delta: "+8.3 vs v0.2", us: true },
    { name: "Claude 4.5 Haiku", size: "—", gpqa: "74.0", math: "86.2", calib: "0.78", delta: "" },
    { name: "GPT-5 Mini",      size: "—", gpqa: "73.1", math: "85.9", calib: "0.74", delta: "" },
    { name: "Gemini 2.5 Flash", size: "—", gpqa: "70.2", math: "83.4", calib: "0.69", delta: "" },
    { name: "Reasoner v0.2",   size: "7B", gpqa: "64.1", math: "78.0", calib: "0.83", delta: "Feb 2026" },
  ];
  return (
    <section className="wk-bench">
      <div className="wk-container">
        <div className="wk-bench__eyebrow">◇ Eval suite — March 2026</div>
        <h2>Calibration is the benchmark<br/>most papers don’t <em>publish.</em></h2>
        <table className="wk-bench__table">
          <thead>
            <tr><th>Model</th><th>Params</th><th style={{textAlign:"right"}}>GPQA-Hard</th><th style={{textAlign:"right"}}>MATH</th><th style={{textAlign:"right"}}>Calibration</th><th style={{textAlign:"right"}}>Note</th></tr>
          </thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.name} className={r.us ? "us" : ""}>
                <td>{r.name}</td>
                <td style={{color: "var(--vellum-300)"}}>{r.size}</td>
                <td className="num">{r.gpqa}</td>
                <td className="num">{r.math}</td>
                <td className="num">{r.calib}</td>
                <td className="delta">{r.delta}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

Object.assign(window, { WMark, Brand, TopNav, Footer, Hero, Manifesto, Features, BenchmarkBand });
