/* Page-level views for the marketing kit. */

function HomePage({ onNavigate }) {
  return (
    <>
      <Hero onCta={() => onNavigate("article")}/>
      <Manifesto/>
      <Features/>
      <BenchmarkBand/>
    </>
  );
}

function ModelCardPage({ onNavigate }) {
  return (
    <article className="wk-article wk-container--tight">
      <div className="crumb">
        <a onClick={() => onNavigate("home")}>Home</a><span>/</span>
        <a onClick={() => onNavigate("research")}>Research</a><span>/</span>
        <span>Model card</span>
      </div>
      <h1>Reasoner v0.3 — <em>model card.</em></h1>
      <p className="dek">A 7B reasoning model. Trained on calibration. Released April 14, 2026 under the WSL-1.0 licence.</p>
      <div className="meta">
        <span><b>Author</b> The Wolknitive lab</span>
        <span><b>Released</b> April 14, 2026</span>
        <span><b>Version</b> v0.3.1</span>
        <span><b>Reading time</b> 14 min</span>
      </div>

      <div className="wk-spec">
        <dl>
          <dt>Parameters</dt><dd><span className="mono">7.2 B</span> &nbsp;— dense, decoder-only</dd>
          <dt>Context</dt><dd><span className="mono">204,800</span> tokens</dd>
          <dt>Training data</dt><dd>Public web (filtered), licensed press archives, mathematics corpora (1.4 T tokens)</dd>
          <dt>Post-training</dt><dd>Calibration RL on 410 k traced reasoning chains</dd>
          <dt>Hardware</dt><dd>2,048 × H200 over 38 days</dd>
          <dt>Licence</dt><dd><span className="mono">WSL-1.0</span> &nbsp;— research + commercial, with usage policy</dd>
        </dl>
      </div>

      <div className="wk-article__body">
        <h2>What the model is for</h2>
        <p>Reasoner v0.3 is small enough to run on a laptop and large enough to handle a 200,000-token document without falling apart. It is tuned to do one thing in particular: when it does not know the answer, it says so — at the resolution of the step in the trace where it hit the wall.</p>
        <p>That sentence is doing more work than it looks. Most reasoning models are confident at the granularity of the final answer. Reasoner is confident at the granularity of the trace.</p>

        <p className="pull">Reason that doesn’t admit its limits isn’t reason. It’s decoration.</p>

        <h2>What it is not for</h2>
        <ul>
          <li>Open-ended creative writing. Use a larger model.</li>
          <li>Real-time multi-turn chat. The trace UI assumes you want to read.</li>
          <li>Image, audio, or video understanding. Reasoner is text-only.</li>
          <li>Code generation longer than ~200 lines. Calibration degrades.</li>
        </ul>

        <h2>How it was evaluated</h2>
        <p>We evaluated on <code>GPQA-Hard</code>, <code>MATH</code>, and a calibration suite of our own. All raw outputs, prompts, and seeds are published on the <a style={{color: "var(--teal-500)", textDecoration: "underline"}}>evals repo</a>. There is no best-of-N, no judge model, no temperature sweep cherry-picked at write-up time.</p>

        <h2>Known failure modes</h2>
        <ul>
          <li>Long arithmetic over 30 digits. Step 4 is reliably the weakest link.</li>
          <li>Questions that depend on April 2026 events. Knowledge cut-off is February.</li>
          <li>Adversarial prompt injection in the long-context passage. Mitigation is in flight.</li>
        </ul>

        <div className="end-mark">◇</div>
      </div>
    </article>
  );
}

function DocsPage({ onNavigate }) {
  const [section, setSection] = useState("quickstart");
  const nav = {
    "Getting started": [
      ["quickstart", "Quickstart"],
      ["install", "Install the CLI"],
      ["auth", "Authentication"],
    ],
    "Reasoner API": [
      ["trace", "Tracing a prompt"],
      ["budget", "Reasoning budgets"],
      ["calib", "Reading calibration"],
    ],
    "Console": [
      ["workspace", "The workspace"],
      ["share", "Sharing traces"],
    ],
  };
  const content = {
    quickstart: (
      <>
        <h1>Quickstart.</h1>
        <p className="dek">Five minutes from sign-up to your first trace.</p>
        <div className="wk-article__body">
          <p>Install the Wolknitive CLI, set a key, and trace a prompt against Reasoner v0.3. The CLI ships with the same renderer as the console — your trace looks the same in either place.</p>
          <h2>Install</h2>
          <p><code>brew install wolknitive/tap/wk</code></p>
          <h2>Authenticate</h2>
          <p><code>wk login</code> — opens the browser; takes about ten seconds.</p>
          <h2>Trace a prompt</h2>
          <p><code>wk reason "Why does the document refer to fiscal year, not calendar year?" &nbsp;--doc report.pdf</code></p>
          <p>The trace will stream into the terminal. Each step is labelled with a calibration score; values below 0.5 are highlighted in amber.</p>
          <p className="pull">A trace you can read is a trace you can correct.</p>
          <h2>Next</h2>
          <p>Read about <a style={{color: "var(--teal-500)", textDecoration: "underline"}} onClick={() => setSection("budget")}>reasoning budgets</a> — the single most important setting in the API.</p>
        </div>
      </>
    ),
  };
  return (
    <div className="wk-docs wk-container">
      <aside className="wk-docs__sidebar">
        {Object.entries(nav).map(([group, items]) => (
          <div key={group}>
            <h4>{group}</h4>
            <ul>
              {items.map(([id, label]) => (
                <li key={id}>
                  <a className={section === id ? "active" : ""} onClick={() => setSection(id)}>
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </aside>
      <main className="wk-article" style={{padding: 0}}>
        {content[section] || (
          <div>
            <h1>Coming soon.</h1>
            <p className="dek">This page is part of the v0.3 release rollout. The quickstart is canonical for now.</p>
          </div>
        )}
      </main>
    </div>
  );
}

Object.assign(window, { HomePage, ModelCardPage, DocsPage });
