/* App shell — toggles between home / model card / docs. */

const { useState } = React;

function App() {
  const [page, setPage] = useState("home");

  // External links route to internal stand-ins (no real product app in this kit).
  const onNavigate = (id) => {
    if (id === "models" || id === "research" || id === "article") setPage("article");
    else if (id === "docs") setPage("docs");
    else if (id === "console") setPage("docs");
    else setPage("home");
  };

  let body;
  if (page === "article") body = <ModelCardPage onNavigate={onNavigate}/>;
  else if (page === "docs") body = <DocsPage onNavigate={onNavigate}/>;
  else body = <HomePage onNavigate={onNavigate}/>;

  return (
    <div className="wk-shell" data-screen-label={page === "home" ? "01 Home" : page === "article" ? "02 Model card" : "03 Docs"}>
      <TopNav current={page === "article" ? "research" : page === "docs" ? "docs" : "product"} onNavigate={onNavigate}/>
      {body}
      <Footer onNavigate={onNavigate}/>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
