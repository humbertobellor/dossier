# Marketing UI kit

The public wolknitive.ai website — three pages, click-through.

```
index.html        ← entry; loads CSS + JSX
marketing.css     ← page styles (relies on ../../colors_and_type.css)
components.jsx    ← TopNav, Footer, Hero, Manifesto, Features, BenchmarkBand, WMark, Brand
pages.jsx         ← HomePage, ModelCardPage, DocsPage
app.jsx           ← shell + simple page router
```

## Screens

1. **Home** — hero, manifesto with drop-cap, six-feature grid, benchmark table on the ink panel.
2. **Model card** — editorial article view. Shows the brand’s long-form treatment: spec table, pull quote in plum, marginalia.
3. **Docs** — sidebar nav + article body. Demonstrates internal navigation and code snippets.

## Patterns to copy

- The `.wk-hero__rule` editorial double-line under the hero CTA.
- `.wk-feat-grid` — 3-column grid with 1px gutter that reads as ledger ruling, not as cards.
- `.wk-bench` — the ink-panel benchmark table. The brand’s only inverted surface in marketing.
- `.wk-article__body h2::before` — every `<h2>` gets a soft `§ ` prefix.
- `.wk-spec` — heavy top rule + paired `<dt>/<dd>` is the brand’s default tabular type.

## What is not here

- Pricing, careers, blog index. Patterns from Docs + Model card cover them — replicate, don’t reinvent.
- Real navigation; clicks route through a tiny `onNavigate` switch.
